@echo off
cd /d "%~dp0"
"C:\Users\starm\AppData\Local\Python\pythoncore-3.14-64\python.exe" "Radeon_RAM_Booster.py"
pause